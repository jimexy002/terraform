import json
import boto3
import os

def lambda_handler(event, context):
    secret_arn = os.environ['SECRET_ARN']
    db_endpoint = os.environ['DB_ENDPOINT']
    
    # Initialize internal Secrets Manager client
    client = boto3.client('secretsmanager')
    
    try:
        response = client.get_secret_value(SecretId=secret_arn)
        credentials = json.loads(response['SecretString'])
        
        # Pull generated components safely
        username = credentials['username']
        password = credentials['password']
        
        print(f"Successfully retrieved credentials for {username}")
        print(f"Target Private Database Endpoint: {db_endpoint}")
        
        # Connect to DB string processing can go here safely...
        return {
            'statusCode': 200,
            'body': json.dumps('Successfully fetched secrets internally!')
        }
    except Exception as e:
        print(e)
        raise e
